Sound Credit - I did not make a majority of the custom sounds found in this resourcepack.

A big special thanks to the following folks:

Novice- https://freesound.org/people/nolhananas/sounds/476340/
Seasoned- https://freesound.org/people/colorsCrimsonTears/sounds/580310/


