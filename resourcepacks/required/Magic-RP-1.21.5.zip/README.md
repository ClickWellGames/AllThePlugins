# Magic Resource Pack

This RP is meant for use with the Magic Bukkit plugin:

https://github.com/elBukkit/MagicPlugin/wiki

## RP Credits

- 3D Artists:
  - RealFlamegirl (Discord flame#0464)
  - Dr00bles
  - Phantom
  - Night
  - Toffy
  - Atrelyu
  - Lix3nn (https://sketchfab.com/Lix3nn/models)

- 2D Artists:
  - realflamegirl (Discord flame#0464)
  - Dr00bles
  - eleazzaar
  - Claire Meyers (https://www.behance.net/gallery/18354273/D-D-Class-Icon-System)
  - https://vectorified.com/download-image#rpg-icon-1.png
  - Forrest Imel (https://www.unrealengine.com/marketplace/150-fantasy-spell-icons-pack)
  - MutimEndymion
  - Negative Spaces Font from AmberWat: https://github.com/AmberWat/NegativeSpaceFont

- Sound Effects:
  - Dr00bles
  - S-Toad (Flute samples for Ocarina)
