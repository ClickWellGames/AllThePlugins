# Storage Resource Pack

This is th Resource Pack for [simple-storage-v2](https://modrinth.com/datapack/simple-storage-v2) but it doesnt work, so if you can help me would really nice!
